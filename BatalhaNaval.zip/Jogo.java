package batalhanaval;

import java.util.*;

public class Jogo {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

        // Permite acessar os métodos da classe BatalhaNaval
        BatalhaNaval jogo = new BatalhaNaval(); 

        System.out.println(" BEM-VINDO AO JOGO BATALHA NAVAL!");
        System.out.println("Afunde todas as embarcações com o menor número de tiros possível.");
        System.out.println("Regras básicas:");
        System.out.println("- Informe as coordenadas da linha e coluna (de 1 a 10).");
        System.out.println("- Você será informado se acertou, afundou ou errou.");
        System.out.println("- Símbolos: ");
        System.out.println(" A/S/C/E/P = partes de navios acertadas");
        System.out.println("   -         = água");
        System.out.println("  X         = navio já destruído (Tabuleiro interno)");

        jogo.inicializarTabuleiros();  // Preenche o tabuleiro com água e espaços
        jogo.posicionarEmbarcacoesFixas(); //Posiciona os navios em posições fixas
        //jogo.exibirTabuleiroCompleto(); Tabuleiro com as posições das embarcações

        int tiros = 0; //contabilizador de tiros

        //Laço principal do jogo: repete enquanto ainda houver navios vivos
        while (!jogo.verificarFimDeJogo()) {
            jogo.exibirTabuleiroVisivel(); //Mostra o tabuleiro visível para o jogador

            System.out.print("Informe linha (1-10): ");
            int linha = entrada.nextInt() - 1; 

            System.out.print("Informe coluna (1-10): ");
            int coluna = entrada.nextInt() - 1;

            // Verifica se a entrada está dentro dos limites válidos
            if (linha < 0 || linha >= 10 || coluna < 0 || coluna >= 10) {
                System.out.println("Coordenadas inválidas! Tente novamente.");
            } else {
                jogo.processarTiro(linha, coluna); // Realiza o tiro
                tiros++;
            }
        }

        // Exibe o resultado final
        jogo.exibirTabuleiroVisivel();
        System.out.println("Fim de jogo! Número total de tiros = " + tiros);
        System.out.println("Legenda:");
        System.out.println("  A/S/C/E/P = partes de navios acertadas");
        System.out.println("  -         = água atingida");
        System.out.println("  espaço    = posição não jogada");
    }

}
