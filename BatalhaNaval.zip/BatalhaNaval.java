package batalhanaval;

public class BatalhaNaval {

    int tamanho = 10;
    char[][] tabuleiro = new char[tamanho][tamanho]; //Matriz oculta com os navios
    char[][] visivel = new char[tamanho][tamanho]; //Matriz mostrada ao jogador

    public void inicializarTabuleiros() {
        for (int i = 0; i < tamanho; i++) {
            for (int j = 0; j < tamanho; j++) {
                tabuleiro[i][j] = '.'; // Ponto representa água
                visivel[i][j] = ' '; // espaço representa posição ainda não jogada
            }
        }
    }

    // Posiciona manualmente os navios em posições fixas
    public void posicionarEmbarcacoesFixas() {
        // Hidroaviões(A)
        tabuleiro[0][0] = 'A';
        tabuleiro[2][4] = 'A';
        tabuleiro[5][6] = 'A';
        tabuleiro[8][1] = 'A';
        tabuleiro[9][8] = 'A';

        // Submarinos(S)
        tabuleiro[1][2] = 'S';
        tabuleiro[3][5] = 'S';
        tabuleiro[6][1] = 'S';
        tabuleiro[7][7] = 'S';

        // Cruzadores(C)- 2 células
        tabuleiro[0][5] = 'C';
        tabuleiro[0][6] = 'C';
        tabuleiro[4][0] = 'C';
        tabuleiro[5][0] = 'C';
        tabuleiro[9][5] = 'C';
        tabuleiro[9][6] = 'C';

        //Encouraçados(E)- 3 células
        tabuleiro[2][7] = 'E';
        tabuleiro[3][7] = 'E';
        tabuleiro[4][7] = 'E';
        tabuleiro[6][4] = 'E';
        tabuleiro[7][4] = 'E';
        tabuleiro[8][4] = 'E';

        //Porta-aviões(P)- 4 células
        tabuleiro[5][9] = 'P';
        tabuleiro[6][9] = 'P';
        tabuleiro[7][9] = 'P';
        tabuleiro[8][9] = 'P';
    }

    public void exibirTabuleiroVisivel() {
        System.out.println("  1 2 3 4 5 6 7 8 9 10"); //Numera as linhas
        for (int i = 0; i < tamanho; i++) {
            if (i + 1 < 10) {
                System.out.print(" " + (i + 1) + " "); //Numera as colunas de 1 a 9
            } else {
                System.out.print((i + 1) + " "); // Numera a coluna 10
            }
            for (int j = 0; j < tamanho; j++) {
                System.out.print(visivel[i][j] + " "); //Exibe cada elemento da matriz
            }
            System.out.println();
        }
    }

    public void processarTiro(int linha, int coluna) {
        if (visivel[linha][coluna] != ' ') { //Verifica se as coordenadas do tiro já foram usadas anteriormente
            System.out.println("Você já atirou nessa posição!");
            return; //Interrompe, impedindo que o restante do método seja executado para o tiro repetido
        }

        char alvo = tabuleiro[linha][coluna]; 

        // Comparação do tabuleiro oculto com os tiros dados pelo jogador
        if (alvo == '.') {
            visivel[linha][coluna] = '-'; //na posição que tiver água e o usuário atirar, vai ser exibido na matriz '-'
            System.out.println("Água.");
        } else {
            visivel[linha][coluna] = alvo;
            tabuleiro[linha][coluna] = 'X';
            if (embarcacaoAfundou(alvo)) {
                System.out.println("Afundou a embarcação " + nomearEmbarcacao(alvo));
            } else {
                System.out.println("Acertou a embarcação " + nomearEmbarcacao(alvo));
            }
        }
    }

    //Verifica se ainda há o tipo da embarcação atingida
    public boolean embarcacaoAfundou(char letra) {
        for (int i = 0; i < tamanho; i++) {
            for (int j = 0; j < tamanho; j++) {
                if (tabuleiro[i][j] == letra) { 
                    return false;
                }
            }
        }
        return true;
    }

    //Verifica se todas as embarcações foram atingidas
    public boolean verificarFimDeJogo() {
        for (int i = 0; i < tamanho; i++) {
            for (int j = 0; j < tamanho; j++) {
                if (tabuleiro[i][j] != '.' && tabuleiro[i][j] != 'X') { 
                    return false;
                }
            }
        }
        return true;
    }

    public String nomearEmbarcacao(char letra) {
        if (letra == 'A') {
            return "Hidroavião";
        } else if (letra == 'S') {
            return "Submarino";
        } else if (letra == 'C') {
            return "Cruzador";
        } else if (letra == 'E') {
            return "Encouraçado";
        } else if (letra == 'P') {
            return "Porta-aviões";
        } else {
            return "Desconhecida";
        }
    }

    public void exibirTabuleiroCompleto() {
        System.out.println("Tabuleiro com as posições das embarcações:");
        for (int i = 0; i < tamanho; i++) {
            for (int j = 0; j < tamanho; j++) {
                System.out.print(tabuleiro[i][j] + " ");
            }
            System.out.println();
        }
    }
}
